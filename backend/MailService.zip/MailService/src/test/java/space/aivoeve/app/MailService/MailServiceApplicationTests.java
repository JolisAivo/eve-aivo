package space.aivoeve.app.MailService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
